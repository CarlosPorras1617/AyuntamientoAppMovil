class PokemonesModel {
  String? name;
  String? url;

  PokemonesModel({
    this.name,
    this.url,
  });

  factory PokemonesModel.fromJson(Map<String, dynamic> pokemon) =>
      PokemonesModel(
        name: pokemon['name'],
        url: pokemon['url'],
      );
}
