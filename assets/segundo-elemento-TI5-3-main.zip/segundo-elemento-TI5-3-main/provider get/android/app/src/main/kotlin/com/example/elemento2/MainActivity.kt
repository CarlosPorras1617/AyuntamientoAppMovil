package com.example.elemento2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
