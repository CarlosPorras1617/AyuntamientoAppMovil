import 'package:flutter/material.dart';

class InventarioPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('Hola estoy en la seccion de inventario'),
          CircleAvatar(
            radius: 50.0,
            backgroundImage: NetworkImage(
                'https://www.ceupe.com/images/easyblog_articles/2294/inventories.jpg'),
          ),
        ],
      ),
    );
  }
}
