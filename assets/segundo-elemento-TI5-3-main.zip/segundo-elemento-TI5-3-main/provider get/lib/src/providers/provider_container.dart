import 'package:get/get.dart';
import 'package:flutter/material.dart';

class ProviderContainer extends GetxController {
  Color _colorContainer = Colors.pink;

  Color get colorContainer => _colorContainer;

  set colorContainer(Color color) {
    _colorContainer = color;
    update();
  }
}
