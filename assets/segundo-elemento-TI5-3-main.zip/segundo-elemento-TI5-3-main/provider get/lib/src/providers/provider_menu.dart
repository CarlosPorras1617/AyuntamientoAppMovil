import 'package:get/get.dart';

class ProviderMenu extends GetxController {
  int _indexMenu = 0;

  int get indexMen => _indexMenu;

  set indexMen(int index) {
    _indexMenu = index;
    update();
  }
}
